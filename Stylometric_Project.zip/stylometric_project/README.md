# Stylometric Analysis of Hindi Literary Texts
### Semester 2 Micro Project

Detects the writing style/author of a Hindi text passage using Machine Learning.

---

## Project Structure

```
stylometric_project/
├── data/                     ← Raw author text files (one folder per author)
│   ├── agyaya/
│   ├── jainendra kumar/
│   ├── jaishankar prasad/
│   ├── munshi premchand/
│   └── Phanishwar Nath Renu/
├── results/                  ← Auto-generated after training
│   ├── confusion_matrix.png
│   ├── f1_per_author.png
│   ├── dataset_split.png
│   ├── samples_per_author.png
│   └── classification_report.csv
├── train.py                  ← Step 1: Train the model
├── app.py                    ← Step 2: Run the UI
├── model.pkl                 ← Auto-generated after training
└── requirements.txt
```

---

## How to Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Train the model
```bash
python train.py
```
This will:
- Read all author `.txt` files from `data/`
- Split data: **70% Train | 15% Validation | 15% Test**
- Train a Character n-gram TF-IDF + LinearSVM model
- Save `model.pkl` and all result charts to `results/`

### Step 3 — Run the UI
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`  
Paste any Hindi text → click **Detect Author** → see results!

---

## Workflow (from notes)
```
Research Paper Reading
        ↓
Dataset (Web Scraping / Manually collected)
        ↓
Preprocessor
  → Normalisation (UTF-8 encoding, Hindi characters)
  → Dead Character Removal (unnecessary symbols)
  → Excess Space Removal
        ↓
Processed Dataset of different writers
        ↓
ML Split (70% Train / 15% Validation / 15% Test)
        ↓
Vector Method (Character n-gram)
  → Writing habits
  → Character usage patterns
  → Language-specific stylistic features
        ↓
5-class Classification
        ↓
Linear Classifier (LinearSVM)
```

---

## Authors in Dataset
| Author | Files |
|--------|-------|
| Agyeya | 10 |
| Jainendra Kumar | 9 |
| Jaishankar Prasad | 11 |
| Munshi Premchand | 10 |
| Phanishwar Nath Renu | 10 |
