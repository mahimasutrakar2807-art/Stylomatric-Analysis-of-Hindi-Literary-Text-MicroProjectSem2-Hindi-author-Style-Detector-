# train.py
# Stylometric Analysis of Hindi Literary Text
# Trains a model on author data and saves it for use in the UI
# ─────────────────────────────────────────────────────────────────────

import os
import re
import pickle
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    classification_report, confusion_matrix, accuracy_score
)

# ── CONFIG ────────────────────────────────────────────────────────────
DATA_DIR   = "data"
MODEL_FILE = "model.pkl"      # saved trained model + vectorizer
RESULTS    = "results"
CHUNK_SIZE = 300              # words per sample
MIN_WORDS  = 120              # discard smaller chunks

os.makedirs(RESULTS, exist_ok=True)


# ── STEP 1: PREPROCESS TEXT ───────────────────────────────────────────
def clean(text):
    text = text.lower()
    text = re.sub(r'\d+', ' ', text)                    # remove numbers
    text = re.sub(r'[^\w\s\u0900-\u097F]', ' ', text)  # remove punctuation (keep Hindi)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


# ── STEP 2: BUILD DATASET FROM RAW .TXT FILES ─────────────────────────
def build_dataset():
    texts, labels = [], []
    for author in os.listdir(DATA_DIR):
        author_path = os.path.join(DATA_DIR, author)
        if not os.path.isdir(author_path):
            continue
        for fname in os.listdir(author_path):
            if not fname.endswith(".txt"):
                continue
            fpath = os.path.join(author_path, fname)
            try:
                with open(fpath, encoding="utf-8", errors="ignore") as f:
                    content = clean(f.read().strip())
                words = content.split()
                for i in range(0, len(words), CHUNK_SIZE):
                    chunk = words[i : i + CHUNK_SIZE]
                    if len(chunk) >= MIN_WORDS:
                        texts.append(" ".join(chunk))
                        labels.append(author.strip())
            except Exception as e:
                print(f"  Skipped {fpath}: {e}")
    return texts, labels


# ── STEP 3: SPLIT  70 / 15 / 15 ──────────────────────────────────────
def split_data(texts, labels):
    df = pd.DataFrame({"text": texts, "label": labels})

    # 70 % train, 30 % temp
    train_df, temp_df = train_test_split(
        df, test_size=0.30, random_state=42, stratify=df["label"]
    )
    # 15 % val, 15 % test  (split temp 50/50)
    val_df, test_df = train_test_split(
        temp_df, test_size=0.50, random_state=42, stratify=temp_df["label"]
    )
    return train_df, val_df, test_df


# ── STEP 4: TRAIN MODEL (Character n-gram TF-IDF  + Linear SVM) ───────
def train(train_df, val_df):
    # Character-level n-gram vectoriser  (captures writing habits,
    # character usage patterns, language-specific stylistic features)
    vectorizer = TfidfVectorizer(
        analyzer   = "char_wb",   # character n-gram (word boundary aware)
        ngram_range= (2, 4),      # bi-grams to 4-grams
        max_features=50000,
        sublinear_tf=True
    )
    X_train = vectorizer.fit_transform(train_df["text"])
    X_val   = vectorizer.transform(val_df["text"])

    model = LinearSVC(C=1.0, max_iter=2000)
    model.fit(X_train, train_df["label"])

    val_acc = accuracy_score(val_df["label"], model.predict(X_val))
    print(f"  Validation accuracy: {val_acc*100:.2f}%")
    return model, vectorizer


# ── STEP 5: EVALUATE ON TEST SET ─────────────────────────────────────
def evaluate(model, vectorizer, test_df):
    X_test = vectorizer.transform(test_df["text"])
    y_pred = model.predict(X_test)
    y_true = test_df["label"]

    acc    = accuracy_score(y_true, y_pred)
    report = classification_report(y_true, y_pred, output_dict=True)
    cm     = confusion_matrix(y_true, y_pred, labels=model.classes_)

    return acc, report, cm, y_pred


# ── STEP 6: SAVE CHARTS ───────────────────────────────────────────────
def save_charts(report, cm, labels, acc,
                train_df, val_df, test_df):

    # ── Chart 1: Confusion matrix ─────────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=[l.title() for l in labels],
        yticklabels=[l.title() for l in labels], ax=ax
    )
    ax.set_title(f"Confusion Matrix  (Test Accuracy: {acc*100:.1f}%)",
                 fontsize=13, fontweight="bold")
    ax.set_ylabel("True Author",    fontsize=11)
    ax.set_xlabel("Predicted Author", fontsize=11)
    plt.xticks(rotation=30, ha="right", fontsize=8)
    plt.yticks(rotation=0,             fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{RESULTS}/confusion_matrix.png", dpi=160)
    plt.close()

    # ── Chart 2: Per-author F1 scores ─────────────────────────────────
    author_f1 = {
        k.title(): v["f1-score"]
        for k, v in report.items()
        if k not in ("accuracy", "macro avg", "weighted avg")
    }
    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ["#1565C0", "#283593", "#1976D2", "#0288D1", "#0097A7"]
    bars = ax.bar(author_f1.keys(), author_f1.values(),
                  color=colors, edgecolor="white", width=0.55)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 0.008,
                f"{bar.get_height():.2f}",
                ha="center", fontsize=11, fontweight="bold")
    ax.set_ylim(0, 1.1)
    ax.set_title("F1-Score per Author", fontsize=13, fontweight="bold")
    ax.set_ylabel("F1-Score", fontsize=11)
    ax.set_xlabel("Author",   fontsize=11)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    plt.xticks(rotation=15, ha="right", fontsize=9)
    plt.tight_layout()
    plt.savefig(f"{RESULTS}/f1_per_author.png", dpi=160)
    plt.close()

    # ── Chart 3: Dataset split pie ────────────────────────────────────
    sizes  = [len(train_df), len(val_df), len(test_df)]
    lbls   = [f"Train\n{sizes[0]} ({sizes[0]*100//sum(sizes)}%)",
              f"Validation\n{sizes[1]} ({sizes[1]*100//sum(sizes)}%)",
              f"Test\n{sizes[2]} ({sizes[2]*100//sum(sizes)}%)"]
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.pie(sizes, labels=lbls, colors=["#1565C0","#FF9800","#4CAF50"],
           startangle=90, autopct='', textprops={"fontsize": 11})
    ax.set_title("Dataset Split  (70 / 15 / 15)", fontsize=13, fontweight="bold")
    plt.tight_layout()
    plt.savefig(f"{RESULTS}/dataset_split.png", dpi=160)
    plt.close()

    # ── Chart 4: Samples per author ───────────────────────────────────
    all_df = pd.concat([train_df, val_df, test_df])
    counts = all_df["label"].value_counts()
    fig, ax = plt.subplots(figsize=(9, 5))
    b = ax.bar([a.title() for a in counts.index],
               counts.values, color=colors, edgecolor="white", width=0.55)
    for bar in b:
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 1,
                str(int(bar.get_height())),
                ha="center", fontsize=11, fontweight="bold")
    ax.set_title("Total Samples per Author", fontsize=13, fontweight="bold")
    ax.set_ylabel("Number of Samples", fontsize=11)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    plt.xticks(rotation=15, ha="right", fontsize=9)
    plt.tight_layout()
    plt.savefig(f"{RESULTS}/samples_per_author.png", dpi=160)
    plt.close()

    print(f"  Charts saved to {RESULTS}/")


# ── MAIN ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  Stylometric Analysis — Training Pipeline")
    print("=" * 55)

    print("\n[1] Building dataset from raw text files...")
    texts, labels = build_dataset()
    print(f"    Total samples created : {len(texts)}")
    print(f"    Authors found         : {sorted(set(labels))}")

    print("\n[2] Splitting data (70 / 15 / 15)...")
    train_df, val_df, test_df = split_data(texts, labels)
    print(f"    Train : {len(train_df)}")
    print(f"    Val   : {len(val_df)}")
    print(f"    Test  : {len(test_df)}")

    print("\n[3] Training model (Character n-gram TF-IDF + LinearSVM)...")
    model, vectorizer = train(train_df, val_df)

    print("\n[4] Evaluating on test set...")
    acc, report, cm, _ = evaluate(model, vectorizer, test_df)
    print(f"    Test accuracy : {acc*100:.2f}%")

    print("\n[5] Saving charts...")
    save_charts(report, cm, model.classes_, acc,
                train_df, val_df, test_df)

    print("\n[6] Saving trained model...")
    with open(MODEL_FILE, "wb") as f:
        pickle.dump({"model": model, "vectorizer": vectorizer}, f)
    print(f"    Model saved to {MODEL_FILE}")

    # Save a small summary CSV
    rows = []
    for author, vals in report.items():
        if author in ("accuracy", "macro avg", "weighted avg"):
            continue
        rows.append({
            "Author": author.title(),
            "Precision": round(vals["precision"], 3),
            "Recall": round(vals["recall"], 3),
            "F1-Score": round(vals["f1-score"], 3),
            "Support": int(vals["support"]),
        })
    pd.DataFrame(rows).to_csv(f"{RESULTS}/classification_report.csv", index=False)

    print("\n" + "=" * 55)
    print("  Training complete! Run  app.py  to use the UI.")
    print("=" * 55)
