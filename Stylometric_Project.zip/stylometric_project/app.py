# app.py — Hindi Author Style Detector (Bilingual: Hindi + English)
# Run: streamlit run app.py

import os, re, pickle, json, base64
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

st.set_page_config(
    page_title="Hindi Author Style Detector | हिंदी लेखक शैली पहचानकर्ता",
    page_icon="✒️",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE       = os.path.dirname(os.path.abspath(__file__))
MODEL_FILE = os.path.join(BASE, "model.pkl")
RESULTS    = os.path.join(BASE, "results")
IMGCACHE   = os.path.join(BASE, "img_cache.json")

LANG = {
    "en": {
        "title":        "Hindi Author Style Detector",
        "subtitle":     "Identify the unique stylistic fingerprints of legendary Hindi authors.",
        "sidebar_head": "Project Controls",
        "sidebar_info": "This system uses AI to analyze writing patterns in Hindi literature.",
        "model_loaded": "Model Loaded",
        "train_results":"Training Results",
        "authors_in":   "Authors in Model",
        "input_head":   "Input Passage",
        "input_cap":    "Paste your Hindi text selection below:",
        "input_ph":     "Paste Hindi text here… (minimum 50 words recommended)",
        "analyse_btn":  "🔍 Analyse Writing Style",
        "clear_btn":    "✕ Clear",
        "guide_head":   "Analysis Guide",
        "guide_body":   "**Minimum Text**: Use at least 50–100 words.\n\n**Language**: Only Devanagari script (Hindi) is supported.\n\n**Authors included**:\n- Munshi Premchand\n- Jaishankar Prasad\n- Jainendra Kumar\n- Phanishwar Nath Renu\n- Agyeya",
        "detected":     "Detected Author",
        "conf_head":    "Confidence Distribution",
        "viz_head":     "Visualization Reference",
        "profile_head": "Author Profile",
        "stats_head":   "Input Statistics",
        "words":        "Words", "chars": "Characters", "confidence": "Confidence",
        "high": "🟢 High", "medium": "🟡 Medium", "low": "🔴 Low",
        "all_graphs":   "📊 View All Training Graphs",
        "f1_label":     "F1-Score per Author",
        "split_label":  "Dataset Split (70/15/15)",
        "samples_label":"Samples per Author",
        "warn_empty":   "⚠️ Please paste some Hindi text first.",
        "warn_short":   "⚠️ Text is too short — paste at least 50 words.",
        "footer":       "Stylometric Analysis · Hindi Literary Texts · Semester 2 Micro Project",
        "period": "Period", "style_lbl": "Style", "known_lbl": "Known for",
        "strength": "Strength", "author_x": "Author",
        "lang_toggle":  "🇮🇳 हिंदी में देखें",
    },
    "hi": {
        "title":        "हिंदी लेखक शैली पहचानकर्ता",
        "subtitle":     "प्रसिद्ध हिंदी लेखकों की अनूठी शैलीगत पहचान करें।",
        "sidebar_head": "प्रोजेक्ट नियंत्रण",
        "sidebar_info": "यह प्रणाली AI का उपयोग करके हिंदी साहित्य में लेखन पैटर्न का विश्लेषण करती है।",
        "model_loaded": "मॉडल लोड हुआ",
        "train_results":"प्रशिक्षण परिणाम",
        "authors_in":   "मॉडल में लेखक",
        "input_head":   "पाठ्यांश दर्ज करें",
        "input_cap":    "नीचे अपना हिंदी पाठ पेस्ट करें:",
        "input_ph":     "यहाँ हिंदी पाठ पेस्ट करें… (कम से कम 50 शब्द)",
        "analyse_btn":  "🔍 लेखन शैली विश्लेषण करें",
        "clear_btn":    "✕ साफ करें",
        "guide_head":   "विश्लेषण मार्गदर्शिका",
        "guide_body":   "**न्यूनतम पाठ**: कम से कम 50–100 शब्द डालें।\n\n**भाषा**: केवल देवनागरी लिपि (हिंदी) समर्थित है।\n\n**शामिल लेखक**:\n- मुंशी प्रेमचंद\n- जयशंकर प्रसाद\n- जैनेंद्र कुमार\n- फणीश्वर नाथ रेणु\n- अज्ञेय",
        "detected":     "पहचाना गया लेखक",
        "conf_head":    "विश्वास वितरण",
        "viz_head":     "दृश्य संदर्भ",
        "profile_head": "लेखक परिचय",
        "stats_head":   "पाठ आँकड़े",
        "words":        "शब्द", "chars": "अक्षर", "confidence": "विश्वास",
        "high": "🟢 अधिक", "medium": "🟡 मध्यम", "low": "🔴 कम",
        "all_graphs":   "📊 सभी प्रशिक्षण ग्राफ देखें",
        "f1_label":     "प्रति लेखक F1-स्कोर",
        "split_label":  "डेटासेट विभाजन (70/15/15)",
        "samples_label":"प्रति लेखक नमूने",
        "warn_empty":   "⚠️ कृपया पहले कुछ हिंदी पाठ पेस्ट करें।",
        "warn_short":   "⚠️ पाठ बहुत छोटा है — कम से कम 50 शब्द डालें।",
        "footer":       "शैलीमितीय विश्लेषण · हिंदी साहित्य · सेमेस्टर 2 माइक्रो प्रोजेक्ट",
        "period": "कालखंड", "style_lbl": "शैली", "known_lbl": "प्रसिद्धि",
        "strength": "शक्ति", "author_x": "लेखक",
        "lang_toggle":  "🇬🇧 View in English",
    },
}

AUTHORS = {
    "phanishwar nath renu": {
        "display_en": "Phanishwar Nath Renu", "display_hi": "फणीश्वर नाथ रेणु",
        "emoji": "🌾", "years": "1921 – 1977",
        "style_en": "Regionalist · Folkloric · Rural Bihar",
        "style_hi": "क्षेत्रीयवादी · लोककथात्मक · ग्रामीण बिहार",
        "known_en": "Vivid depictions of rural Bihar with Maithili-inflected language",
        "known_hi": "मैथिली प्रभावित भाषा में ग्रामीण बिहार का जीवंत चित्रण",
    },
    "agyaya": {
        "display_en": "Agyeya (S.H. Vatsyayan)", "display_hi": "अज्ञेय (स.हि. वात्स्यायन)",
        "emoji": "🖋️", "years": "1911 – 1987",
        "style_en": "Modernist · Experimental · Stream-of-consciousness",
        "style_hi": "आधुनिकतावादी · प्रयोगशील · चेतना-प्रवाह",
        "known_en": "Pioneer of the Nai Kavita movement",
        "known_hi": "नई कविता आंदोलन के अग्रदूत",
    },
    "jainendra kumar": {
        "display_en": "Jainendra Kumar", "display_hi": "जैनेंद्र कुमार",
        "emoji": "📚", "years": "1905 – 1988",
        "style_en": "Psychological · Introspective · Philosophical",
        "style_hi": "मनोवैज्ञानिक · आत्मचिंतन · दार्शनिक",
        "known_en": "Prominent psychological novelist of modern Hindi literature",
        "known_hi": "आधुनिक हिंदी साहित्य के प्रमुख मनोवैज्ञानिक उपन्यासकार",
    },
    "jaishankar prasad": {
        "display_en": "Jaishankar Prasad", "display_hi": "जयशंकर प्रसाद",
        "emoji": "🌸", "years": "1889 – 1937",
        "style_en": "Romantic · Lyrical · Chhayavaad",
        "style_hi": "रोमांटिक · गीतात्मक · छायावाद",
        "known_en": "Central figure of the Chhayavaad romantic-symbolist movement",
        "known_hi": "छायावाद रोमांटिक-प्रतीकवादी आंदोलन के केंद्रीय स्तंभ",
    },
    "munshi premchand": {
        "display_en": "Munshi Premchand", "display_hi": "मुंशी प्रेमचंद",
        "emoji": "🏛️", "years": "1880 – 1936",
        "style_en": "Realist · Social Commentary · Rural India",
        "style_hi": "यथार्थवादी · सामाजिक टिप्पणी · ग्रामीण भारत",
        "known_en": "Father of modern Hindi literature",
        "known_hi": "आधुनिक हिंदी साहित्य के जनक",
    },
}

def clean(text):
    text = text.lower()
    text = re.sub(r"\d+", " ", text)
    text = re.sub(r"[^\w\s\u0900-\u097F]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

@st.cache_resource(show_spinner=False)
def load_model():
    if not os.path.exists(MODEL_FILE):
        return None, None, 0
    with open(MODEL_FILE, "rb") as f:
        pkg = pickle.load(f)
    mb = os.path.getsize(MODEL_FILE) / 1_048_576
    return pkg["model"], pkg["vectorizer"], mb

@st.cache_data(show_spinner=False)
def load_images():
    if os.path.exists(IMGCACHE):
        with open(IMGCACHE) as f:
            return json.load(f)
    return {}

def make_conf_chart(classes, scores, lang_code, strength_lbl, author_lbl):
    norm   = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
    suffix = "_en" if lang_code == "en" else "_hi"
    labels = [AUTHORS.get(c.lower(), {}).get(f"display{suffix}", c) for c in classes]
    winner = classes[int(np.argmax(scores))]
    colors = ["#c0392b" if c == winner else "#12121e" for c in classes]

    fig, ax = plt.subplots(figsize=(6, 3.6))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.bar(range(len(labels)), norm, color=colors, width=0.52, zorder=3)

    max_v = float(max(norm))
    step  = 0.05
    ticks = [round(i * step, 2) for i in range(int(max_v / step) + 2)]
    ax.set_yticks(ticks)
    ax.set_yticklabels([f"{v:.2f}" for v in ticks], fontsize=8, color="#555")
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=8, color="#333")
    ax.set_ylabel(strength_lbl, fontsize=9, color="#555")
    ax.set_xlabel(author_lbl,   fontsize=9, color="#555")
    ax.set_ylim(0, max_v * 1.28)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#ddd")
    ax.tick_params(left=False, bottom=False)
    ax.yaxis.grid(True, linestyle="--", alpha=0.35, color="#ddd", zorder=0)
    fig.tight_layout(pad=1.2)
    return fig

model, vectorizer, model_mb = load_model()
cached_imgs = load_images()

if "lang" not in st.session_state:
    st.session_state.lang = "en"
lang = st.session_state.lang
T = LANG[lang]

# ── CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Source+Serif+4:ital,wght@0,300;0,400;0,600;1,300&display=swap');

html, body, [class*="css"] {
    font-family: 'Source Serif 4', Georgia, serif;
    background: #ffffff;
}
.main-title { display:flex; align-items:center; gap:12px; margin-bottom:2px; }
.main-title h1 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem; font-weight: 800;
    color: #1a1a2e; margin: 0; letter-spacing: -0.5px;
}
.main-subtitle { font-size:1rem; color:#555; font-style:italic; font-weight:300; margin-bottom:18px; }
.sec-head {
    display:flex; align-items:center; gap:8px;
    font-family:'Playfair Display',serif;
    font-size:1.05rem; font-weight:700; color:#1a1a2e; margin-bottom:8px;
}
.detected-wrap {
    border-left: 5px solid #c0392b;
    padding: 14px 24px 16px;
    margin: 16px 0 22px;
    background: #fff;
    border-radius: 0 6px 6px 0;
}
.detected-label {
    font-size: 0.82rem; color: #c0392b;
    font-weight: 700; letter-spacing: 1.2px;
    text-transform: uppercase; margin-bottom: 8px;
}
.detected-name {
    font-family: 'Playfair Display', serif;
    font-size: 2.0rem; font-weight: 800;
    color: #1a1a2e; letter-spacing: -0.5px;
}
[data-testid="stSidebar"] {
    background: #f9f8f6;
    border-right: 1px solid #ece8e0;
}
textarea {
    font-family: 'Source Serif 4', Georgia, serif !important;
    font-size: 1rem !important; line-height: 1.75 !important;
    color: #1a1a2e !important;
    border: 1.5px solid #ddd !important; border-radius: 6px !important;
}
textarea:focus { border-color: #c0392b !important; }
.stButton > button[kind="primary"] {
    background: #1a1a2e !important; color: #fff !important;
    border: none !important; border-radius: 5px !important;
    font-family: 'Source Serif 4', serif !important;
    font-size: 0.92rem !important; font-weight: 600 !important;
    transition: background 0.2s !important;
}
.stButton > button[kind="primary"]:hover { background: #c0392b !important; }
.stButton > button:not([kind="primary"]) {
    border: 1.5px solid #ddd !important; border-radius: 5px !important; color: #555 !important;
}
hr { border-color: #ece8e0 !important; margin: 18px 0 !important; }
[data-testid="stMetric"] {
    background: #f9f8f6; border: 1px solid #ece8e0;
    border-radius: 8px; padding: 10px 14px !important;
}
[data-testid="stMetricLabel"] { font-size:0.78rem !important; color:#888 !important; }
[data-testid="stMetricValue"] {
    font-family: 'Playfair Display', serif !important;
    font-size: 1.35rem !important; color: #1a1a2e !important;
}
.profile-table { width:100%; border-collapse:collapse; font-size:0.9rem; }
.profile-table td { padding:8px 10px; border-bottom:1px solid #f0ece4; color:#333; }
.profile-table td:first-child { font-weight:600; color:#1a1a2e; width:110px; }
.block-container { padding-top: 1.2rem !important; }
</style>
""", unsafe_allow_html=True)

# ── SIDEBAR ───────────────────────────────────────────────────────────
with st.sidebar:
    if st.button(T["lang_toggle"], key="lang_btn"):
        st.session_state.lang = "hi" if lang == "en" else "en"
        st.rerun()

    st.markdown(f"## 📂 {T['sidebar_head']}")
    st.divider()

    if model is None:
        st.error("⚠️ model.pkl not found.\nRun `python train.py` first.")
        st.stop()

    st.info(T["sidebar_info"])
    st.success(f"✅  {T['model_loaded']} ({model_mb:.2f} MB)")
    st.divider()

    st.markdown(f"### 📊 {T['train_results']}")
    csv_path = os.path.join(RESULTS, "classification_report.csv")
    if os.path.exists(csv_path):
        df_rep  = pd.read_csv(csv_path)
        df_show = df_rep[["Author", "Precision", "Recall"]].copy()
        df_show["Precision"] = df_show["Precision"].round(2)
        df_show["Recall"]    = df_show["Recall"].round(2)
        st.dataframe(df_show, hide_index=True, use_container_width=True)
    st.divider()

    st.markdown(f"### 📁 {T['authors_in']}")
    for meta in AUTHORS.values():
        dn = meta[f"display_{'en' if lang=='en' else 'hi'}"]
        st.markdown(f"**{meta['emoji']} {dn}**  \n_{meta['years']}_")

# ── MAIN ─────────────────────────────────────────────────────────────
st.markdown(f"""
<div class="main-title">
    <span style="font-size:2rem">✒️</span>
    <h1>{T['title']}</h1>
</div>
<p class="main-subtitle">{T['subtitle']}</p>
""", unsafe_allow_html=True)

st.divider()

col_in, col_guide = st.columns([2, 1], gap="large")

with col_in:
    st.markdown(f'<div class="sec-head">📝 {T["input_head"]}</div>', unsafe_allow_html=True)
    st.caption(T["input_cap"])
    input_text = st.text_area(
        label="text", height=300,
        placeholder=T["input_ph"],
        label_visibility="collapsed",
        key="input_text",
    )
    b1, b2 = st.columns([3, 1])
    with b1:
        run = st.button(T["analyse_btn"], type="primary", use_container_width=True)
    with b2:
        if st.button(T["clear_btn"], use_container_width=True):
            st.rerun()

with col_guide:
    st.markdown(f'<div class="sec-head">📌 {T["guide_head"]}</div>', unsafe_allow_html=True)
    st.markdown(T["guide_body"])

st.divider()

# ── PREDICTION ────────────────────────────────────────────────────────
if run:
    text = input_text.strip()
    if not text:
        st.warning(T["warn_empty"])
    elif len(text.split()) < 15:
        st.warning(T["warn_short"])
    else:
        cleaned    = clean(text)
        X          = vectorizer.transform([cleaned])
        pred_key   = model.predict(X)[0]
        dec_scores = model.decision_function(X)[0]
        classes    = model.classes_

        meta  = AUTHORS.get(pred_key.lower(), {})
        dn    = meta.get(f"display_{'en' if lang=='en' else 'hi'}", pred_key.title())
        emoji = meta.get("emoji", "📖")

        # ── DETECTED AUTHOR ───────────────────────────────────────────
        st.markdown(f"""
<div class="detected-wrap">
    <div class="detected-label">{T['detected']}</div>
    <div class="detected-name">{emoji} {dn}</div>
</div>
""", unsafe_allow_html=True)

        # ── CONFIDENCE  |  CONFUSION MATRIX ──────────────────────────
        left, right = st.columns(2, gap="large")

        with left:
            st.markdown(f'<div class="sec-head">📈 {T["conf_head"]}</div>', unsafe_allow_html=True)
            fig = make_conf_chart(classes, dec_scores, lang, T["strength"], T["author_x"])
            st.pyplot(fig, use_container_width=True)
            plt.close()

        with right:
            st.markdown(f'<div class="sec-head">🗂️ {T["viz_head"]}</div>', unsafe_allow_html=True)
            if "confusion_matrix" in cached_imgs:
                st.markdown(
                    f'<img src="data:image/png;base64,{cached_imgs["confusion_matrix"]}" '
                    f'style="width:100%;border-radius:6px;" />',
                    unsafe_allow_html=True
                )
            else:
                cm_img = os.path.join(RESULTS, "confusion_matrix.png")
                if os.path.exists(cm_img):
                    st.image(cm_img, use_column_width=True)

        st.divider()

        # ── AUTHOR PROFILE  |  INPUT STATS ───────────────────────────
        p1, p2 = st.columns(2, gap="large")

        with p1:
            st.markdown(f'<div class="sec-head">👤 {T["profile_head"]}</div>', unsafe_allow_html=True)
            suf = "en" if lang == "en" else "hi"
            st.markdown(f"""
<table class="profile-table">
  <tr><td>{T['period']}</td><td>{meta.get('years','—')}</td></tr>
  <tr><td>{T['style_lbl']}</td><td>{meta.get(f'style_{suf}','')}</td></tr>
  <tr><td>{T['known_lbl']}</td><td>{meta.get(f'known_{suf}','')}</td></tr>
</table>""", unsafe_allow_html=True)

        with p2:
            st.markdown(f'<div class="sec-head">📊 {T["stats_head"]}</div>', unsafe_allow_html=True)
            words = len(text.split())
            chars = len(text.replace(" ", ""))
            level = T["high"] if words > 150 else (T["medium"] if words > 60 else T["low"])
            m1, m2, m3 = st.columns(3)
            m1.metric(T["words"],      words)
            m2.metric(T["chars"],      chars)
            m3.metric(T["confidence"], level)

        st.divider()

        with st.expander(T["all_graphs"], expanded=False):
            g1, g2 = st.columns(2)

            def show_img(col, key, label):
                with col:
                    st.markdown(f"**{label}**")
                    if key in cached_imgs:
                        st.markdown(
                            f'<img src="data:image/png;base64,{cached_imgs[key]}" '
                            f'style="width:100%;border-radius:6px;"/>',
                            unsafe_allow_html=True
                        )
                    else:
                        p = os.path.join(RESULTS, f"{key}.png")
                        if os.path.exists(p):
                            st.image(p, use_column_width=True)

            show_img(g1, "f1_per_author",   T["f1_label"])
            show_img(g2, "dataset_split",   T["split_label"])
            show_img(st, "samples_per_author", T["samples_label"])

# ── FOOTER ────────────────────────────────────────────────────────────
st.markdown(f"""
<div style='text-align:center;color:#aaa;font-size:0.8rem;
            padding-top:36px;border-top:1px solid #ece8e0;margin-top:20px;'>
    {T['footer']}
</div>
""", unsafe_allow_html=True)
